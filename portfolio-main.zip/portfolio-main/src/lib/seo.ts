import { buildMetadata } from '@/config/site.config';
export { buildMetadata };
