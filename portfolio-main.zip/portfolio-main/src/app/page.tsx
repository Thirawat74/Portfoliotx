import { HeroSection } from '@/components/sections/hero';


export default function Home() {
  return (
    <main className="w-full">
        <HeroSection />

    </main>
  );
}
